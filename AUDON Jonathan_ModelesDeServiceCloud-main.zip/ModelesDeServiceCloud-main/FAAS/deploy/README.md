# Déploiement des conteneurs FaaS vers le cloud

## Comment utiliser ?

Pensez a remplacer le '.env.example' et renommez le en '.env'

## Le script ansible 'functionAsAService.yml'

Prenez le soin de lire le script et de l'adapter a votre besoin

## Les commandes

```bash
make deploy_faas 
```