# Utilisez le container as a service CAAS de microsoft azure



# Plus et decouvertes

Automatiser la configuration du serveur DNS pour lier les microservices Docker en tant qu'adresses DNS, en s'appuyant sur Bind et Python support DoH (DNS over HTTPS):
https://github.com/Maissacrement/automate_dns/tree/main


Chaque périphérique réseau est émulé par un conteneur. Les périphériques de réseau virtuel sont interconnectés par des réseaux locaux L2 virtuels.
image utilisé: Quagga, FRRouting, Bind, P4, OpenVSwitch, and more
https://github.com/KatharaFramework/Kathara
