# Deploiement Infrastructure as a Service (IAAS)

Consultez le script Ansible : chaque tâche non documentée (indiquée par "...") devra être modifiée et complétée pour permettre l'instanciation de votre machine virtuelle Azure. Le lien de la documentation de chaque module ont été ajouté au dessus du tache du module ansible courant.
Dans "debug" -> "msg".

## Comment utiliser ?

Pensez a remplacer le '.env.example' et renommez le en '.env'

## Le script ansible 'deploy.yml'

Prenez le soin de lire le script et de l'adapter a votre besoin

## Les commandes

```bash
make deploy_iaas
```